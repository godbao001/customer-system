#!/usr/bin/env python3
"""聊天记录备份工具 - 将 jsonl 转换为 HTML 格式"""
import json
import os
from datetime import datetime

SESSIONS_DIR = "/root/.openclaw/agents/main/sessions"
OUTPUT_DIR = "/root/.openclaw/workspace/chat_backups"

def parse_timestamp(ts_ms):
    """将毫秒时间戳转换为可读时间"""
    try:
        ts = int(ts_ms) / 1000
        dt = datetime.fromtimestamp(ts)
        return dt.strftime("%H:%M")
    except:
        return ""

def extract_text_content(content):
    """从消息内容中提取文本"""
    if isinstance(content, list):
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                return item.get("text", "")
    return ""

def process_session_file(filepath):
    """处理单个 session 文件"""
    messages = []
    session_time = ""
    
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip():
                continue
            try:
                data = json.loads(line)
                
                if data.get("type") == "session":
                    # 获取会话开始时间
                    ts = data.get("timestamp", "")
                    if ts:
                        dt = datetime.fromtimestamp(float(ts.replace("Z", "").replace("T", " ").split(".")[0][:19]))
                        session_time = dt.strftime("%Y-%m-%d")
                
                if data.get("type") == "message":
                    msg = data.get("message", {})
                    role = msg.get("role", "")
                    content = msg.get("content", [])
                    text = extract_text_content(content)
                    
                    if text and role in ["user", "assistant"]:
                        time = parse_timestamp(data.get("timestamp", 0))
                        messages.append({
                            "role": role,
                            "time": time,
                            "text": text
                        })
            except:
                continue
    
    return session_time, messages

def generate_html(session_time, messages, filename):
    """生成 HTML 文件"""
    html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>聊天记录 - {session_time}</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; background: #f5f5f5; }}
        h1 {{ color: #333; border-bottom: 2px solid #4CAF50; padding-bottom: 10px; }}
        .message {{ margin: 15px 0; padding: 15px; border-radius: 10px; }}
        .user {{ background: #e3f2fd; margin-left: 50px; }}
        .assistant {{ background: #fff; margin-right: 50px; border: 1px solid #ddd; }}
        .time {{ font-size: 12px; color: #999; margin-bottom: 5px; }}
        .role {{ font-weight: bold; color: #666; margin-right: 10px; }}
        .text {{ line-height: 1.6; }}
    </style>
</head>
<body>
    <h1>🗓️ 聊天记录 - {session_time}</h1>
    <p>共 {len(messages)} 条消息</p>
"""
    
    for msg in messages:
        role_class = "user" if msg["role"] == "user" else "assistant"
        role_name = "你" if msg["role"] == "user" else "AI"
        html += f"""
    <div class="message {role_class}">
        <div class="time"><span class="role">{role_name}</span> {msg["time"]}</div>
        <div class="text">{msg["text"]}</div>
    </div>
"""
    
    html += """
</body>
</html>"""
    
    output_path = os.path.join(OUTPUT_DIR, filename)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)
    
    return output_path

def backup_today():
    """备份今天的聊天记录"""
    today = datetime.now().strftime("%Y-%m-%d")
    output_file = f"chat_{today}.html"
    
    # 获取最新的 session 文件
    sessions_file = os.path.join(SESSIONS_DIR, "sessions.json")
    if os.path.exists(sessions_file):
        with open(sessions_file, 'r', encoding='utf-8') as f:
            sessions_data = json.load(f)
        
        # 找到最新的 session (按 updatedAt 排序)
        latest_session_id = None
        latest_time = 0
        
        for key, session in sessions_data.items():
            if isinstance(session, dict):
                updated_at = session.get("updatedAt", 0)
                if updated_at > latest_time:
                    latest_time = updated_at
                    latest_session_id = session.get("sessionId", "")
        
        if latest_session_id:
            session_file = os.path.join(SESSIONS_DIR, f"{latest_session_id}.jsonl")
            
            if os.path.exists(session_file):
                session_time, messages = process_session_file(session_file)
                if messages:
                    output_path = generate_html(session_time, messages, output_file)
                    print(f"✅ 备份成功: {output_path}")
                    return output_path
    
    print("⚠️ 没有找到今天的聊天记录")
    return None

if __name__ == "__main__":
    backup_today()
